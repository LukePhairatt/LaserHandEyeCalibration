function R = rotationMatrix( ax, ay, az )
% rotationMatrix - returns rotation matrix defined by yaw, pitch and roll
%	   angles
%     R = rotationMatrix( yaw, pitch, roll )
% 
%	   matrix R is obtained in the following way:
%	   1. First rotate frame about x-axis an yaw angle
%	   2. Then, rotate the resulting frame about y-axis an pitch angle
%	   3. Finally, rotate the resulting frame about z-axis an roll angle
%
%      or
%    R = rotationMatrix( [Tx Ty Tz yaw  pitch  roll]' )
%	   Tx,Ty,Tz are translations
%
%    R - 4x4 homogeneous rotation matrix

T = [];

if nargin == 1, 
   if max(size(ax)) == 3,
       ay = ax(2); az = ax(3); ax = ax(1);
   elseif max(size(ax)) == 6,
       T = ax(1:3);
       ay = ax(5); az = ax(6); ax = ax(4);
   end;
end;

if ax ~= 0,
   Rx= [ 1    0       0	       0
         0  cos(ax) -sin(ax)   0
         0  sin(ax)  cos(ax)   0
	 0    0       0        1 ];
end;
if ay ~= 0,
   Ry= [  cos(ay)  0  sin(ay)  0
            0      1    0      0
         -sin(ay)  0  cos(ay)  0
   	    0      0    0      1 ];
end;
if az ~= 0,
   Rz= [  cos(az) -sin(az)  0  0
          sin(az)  cos(az)  0  0
            0        0      1  0
	    0        0      0  1 ];
end

if ax ~= 0,
   if ay ~= 0, 
       if az ~= 0, R = Rz*Ry*Rx;  else R = Ry*Rx; end;
   else
       if az ~= 0, R = Rz*Rx;     else R = Rx;    end;
   end;
else
   if ay ~= 0, 
       if az ~= 0, R = Rz*Ry;     else R = Ry;    end;
   else
       if az ~= 0, R = Rz;        else R = eye(3);end;
   end;
end;

if ~ isempty(T),
   R(1:3,4) = T(:);
end;

return; 
