% handEye - performs hand/eye calibration
% 
%     Hcg = handEye(Hgb, Hwc)
% 
%     Hgb - pose of the robot base relative to the gripper..
%     Hwc - pose of camera relative to the world ..      
%           (relative to the calibration block)
%           Dimension: size(Hwc) = size(Hbg)
%     Hcg - 4x4 homogeneous transformation from camera to gripper      
%           , that is gripper position relative to the camera.
%           Focal point of the camera is positioned, ..
%           .. relative to the gripper, at
%                 f = inv(Hcg)*[0;0;0;1];
%           
% References: R.Tsai, R.K.Lenz "A new Technique for Fully Autonomous 
%           and Efficient 3D Robotics Hand/Eye calibration", IEEE 
%           trans. on robotics and Automaion, Vol.5, No.3, June 1989
%

function Hcg = handEye2(Hgb, Hwc)

M = size(Hgb,3);

K = (M*M-M)/2;               % Number of unique camera position pairs
A = zeros(3*K,3);            % will store: skew(Pgij+Pcij)
B = zeros(3*K,1);            % will store: Pcij - Pgij
k = 0;
for i = 1:M,
   for j = i+1:M;
		Hcij = Hwc(:,:,j)*inv(Hwc(:,:,i));  % Transformation from i-th to j-th camera pose
		Pcij = rot2quat(Hcij);              % ... and the corresponding quaternion

		Hgij = inv(Hgb(:,:,j))*Hgb(:,:,i);  % Transformation from i-th to j-th gripper pose
		Pgij = rot2quat(Hgij);              % ... and the corresponding quaternion
      
      k = k+1;                            % Form linear system of equations
      A((3*k-3)+(1:3), 1:3) = skew(Pgij+Pcij); % left-hand side
      B((3*k-3)+(1:3))      = Pcij - Pgij;     % right-hand side
         
   end;
end;

% Rotation from camera to gripper is obtained from the set of equations:
%    skew(Pgij+Pcij) * Pcg_ = Pcij - Pgij
% Gripper with camera is first moved to M different poses, then the gripper
% .. and camera poses are obtained for all poses. The above equation uses
% .. invariances present between each pair of i-th and j-th pose.

Pcg_ = A \ B;                % Solve the equation A*Pcg_ = B

% Obtained non-unit quaternin is scaled back to unit value that
% .. designates camera-gripper rotation
Pcg = 2 * Pcg_ / sqrt(1 + Pcg_'*Pcg_);

Rcg = quat2rot(Pcg);         % Rotation matrix

Hcg = Rcg;

return