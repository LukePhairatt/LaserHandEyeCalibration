% batch12 - This file is used for verifying algorithms for camera calibration
%           and hand-eye (gripper-camera) calibration


Hcg = [                    % camera to gripper transformation
       1    0    0    0
       0    1    0    0
       0    0    1   50
       0    0    0    1
];
                            % .. so that xg = Hcg*xc 

Hbw = [                     % base to world transformation
      -1    0    0    0
       0    1    0    0
       0    0   -1  580
       0    0    0    1
    ];
    
Hwb = inv(Hbw);


f = 7;                       % focal length

M = 8;                        % number of positions
Hg = zeros(4,4,M);
Hg(:,:,1) = [
 0.927216796049923    0.304984323813709    0.217378875125462    -31.1208890158181
-0.287873163404251     0.95164328088039   -0.107257203706033    -47.1166823999446
-0.239578911664916   0.0368731363339574     0.97017643596531      369.44668782632
                 0                    0                    0                    1
];
Hg(:,:,2) = [
-0.0493325400772797    0.995198701763215    0.084533097058699    -7.92379193289404
 -0.960577283963501  -0.0240904723183314    -0.27696738197265    -23.8594959919734
 -0.273601136735263  -0.0948640772489331    0.957153710134835     371.987216386143
                  0                    0                    0                    1
];
Hg(:,:,3) = [
 0.937830192313246   -0.346307290250272   0.0233621725276868     57.4899686615136
 0.345253197434389    0.923816252233653   -0.165419955780123    -30.1080774271833
0.0357037819709707    0.163201693705919    0.985946472748135     365.611776406664
                 0                    0                    0                    1
];
Hg(:,:,4) = [
0.782404106760422   -0.610700754951058   -0.122018038119921     45.3008933678895
 0.57873378954853    0.785353838547034   -0.219742005802796    -26.0938261202051
0.230023943447686    0.101311086173462    0.967897230732235     372.811149926719
                0                    0                    0                    1
];


Hg(:,:,5) = [
0.777440502811533   -0.601512319910972   -0.183763961601485     94.6953061631105
0.576505679778897    0.798320742052622   -0.174141304667282    -45.5332607093224
0.251450722350967   0.0294435358588609    0.967422147991922     346.712757600776
                0                    0                    0                    1
];

Hg(:,:,6) = [
0.542516860383514     -0.8307768829386    0.124439651937957    -13.8463424913344
0.830897330809144    0.508887323821887   -0.225040701446735    -3.59630484172454
  0.1236328510302    0.225484949449454    0.966370247740441     367.872447939775
                0                    0                    0                    1
];
Hg(:,:,7) = [
  0.480791991469841   -0.872286303424344   0.0891945390523316    -42.6999906593975
  0.876170081649921    0.481895279841017  -0.0101453086950485    -63.0185738543688
-0.0341328135382111   0.0830273697357772    0.995962552968094     340.097844182422
                  0                    0                    0                    1
];
Hg(:,:,8) = [
 0.988728198722957   -0.143862847191346  -0.0414732473777643     25.4782828585389
 0.134130876840972    0.974187187519456   -0.181571560412979    -26.2282828982305
0.0665241078702295    0.173962078830219    0.982502792973709     370.757986415127
                 0                    0                    0                    1
];

if 0,
for i = 1:M,

% Because Hc*Hcg*Hg*Hbw = 1, then
Hgi = Hg(:,:,i);
Hci = inv(Hbw) * inv(Hgi) * inv(Hcg);

disp(['i = ', num2str(i)]);

fid = fopen(['Hc_old', num2str(i), '.txt'], 'W');
if ( fid < 0 ) break; end;

fprintf (fid, '%d %d \n', [0 0] );
disp([ 0  0 ]);             % camera image center
fprintf (fid, '%d \n', f );
disp( f );                  % focal length
fprintf (fid, '%15.5f %15.5f %15.5f \n', Hci(1:3,4)' );
disp( Hci(1:3,4)' );        % translation
fprintf (fid, '%15.5f %15.5f %15.5f \n', Hci(1:3, 1:3) );
disp( Hci(1:3, 1:3) );      % rotation
fprintf (fid, '%d %d \n', [1 1] );
disp([ 1  1 ]);             % image distortion
fprintf (fid, '%d %d \n', [0 0] );
disp([ 0  0 ]);             % dummy data
fclose(fid);
disp( num2str(Hgi(1:3,1:4), 15) );

disp('--------------------------------------------');
end; %for
end; %if


Hc = zeros(4,4,M);           % Camera pose relative to world system
                             % World system contains calibration block
for i=1:M,
   Hc(:,:,i) = Hwb*inv(Hg(:,:,i))*inv(Hcg);   % .. that is calculated from gripper position
end;

% Calculate Pcg_ from equation
%    skew(Pgij+Pcij)*Pcg_ = Pcij - Pgij
% =>               A*Pcg_ = B
% where Pcg = 2 Pcg_ / sqrt(1 + |Pcg_|^2)
% [Tsai89] equation (12)
%
K = (M*M-M)/2;               % Number of unique camera position pairs
A = zeros(3*K,3);            % will store: skew(Pgij+Pcij)
B = zeros(3*K,1);            % will store: Pcij - Pgij
k = 0;
for i = 1:M,
   for j = i+1:M;
      Hgij = inv(Hg(:,:,j))*Hg(:,:,i);
      Hcij = inv(Hc(:,:,j))*Hc(:,:,i);
      Pgij = rot2quat(Hgij);
      Pcij = rot2quat(Hcij);
      k = k+1;
      A((3*k-3)+(1:3), 1:3) = skew(Pgij+Pcij);
      B((3*k-3)+(1:3))      = Pcij - Pgij;
         
   end;
end;

Pcg_ = A \ B;

Pcg = 2 * Pcg_ / sqrt(1 + Pcg_'*Pcg_);

Rcg = quat2rot(Pcg);

disp(Rcg);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


N = 10;                      % number of points on the object
qw = [                       % Points on the object in world coord. sys.
     20 * randn(1,N)         % x-coord
     20 * randn(1,N)         % y-coord
     20 * randn(1,N)         % z-coord
     ones(1,N)
];

qc = Hc(:,:,i) * qw;                % Points on the object transformed 
                             %     to camera coord. sys

x  = qc(1,:);  y = qc(2,:); z = qc(3,:);

u   = - f * [ (x./z) ; (y./z) ]; % projection onto a camera image plane
