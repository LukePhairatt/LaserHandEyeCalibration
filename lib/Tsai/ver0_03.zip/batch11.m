


batch09;                % initialize model parameters

% this matrix contains sample heights of the actuators

heights = [
   111   100   124   115   119   128
   125   108   128   110   127   122
   109   118    99   104   129   128
   109   127   110   115   129   128
   101   128    93    88   126   129
    99   107   106   128   114   114
    76    71    90   113   103   121
   106   110   106   112   126   121
];


for n = 1:8,    
% pick one row from heights
h = heights(n,:);
R = SPForFA(model, h);                                          % calculate forward kinematics for that row
% SPPlot(model, R);
% plot the manipulator in the final pose
% axis normal; axis vis3d; axis equal;
hinv = SPInvFA(model, R);                                       % check the results through inverse kinematics
disp(['n = ', num2str(n)]);                             % display results
disp(['h    = ', num2str(h   , 6)]);
disp(['hinv = ', num2str(hinv, 6)]);
disp('R = '); disp(num2str(R, 15));
disp('');
end
