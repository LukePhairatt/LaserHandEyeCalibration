% Camera to gripper transformation..
% .. that is pose of the camera in gripper coord system.
% Point pg in gripper coordinate system ..
% .. is positioned at ..
% ..    pc = Hcg * pg = inv(Hgc) * pg

Hgc = transl([0;0;50])*quat2rot(0.1*randn(3,1));
Hcg = inv(Hgc);    
                            
Hbw = [                    % base to world transformation
      -1    0    0    0
       0    1    0    0
       0    0   -1  580
       0    0    0    1
];
Hwb = inv(Hbw);            % Pose of the base in the world coordinate system

% Create M random poses of the gripper:
% Platform is positioned at distance D from base ...
% Platform is positioned within circle of diameter 
D = 370; 
M = 10;

[ Hbg, Hgb ] = batch16(M, D, Hbw(3,4));

Hbc = zeros(4,4,M);
Hwc = zeros(4,4,M);
Hcw = zeros(4,4,M);           % World system relative to the camera
                              % .. or transformation from camera to world
                              % .. => a point in world xw 
                              %    .. will be positioned at xc = Hcw*xw relative to the camera
                              % World system contains calibration block
for i=1:M,                    % For all gripper positions, calculate camera position
   Hbc(:,:,i) = Hbg(:,:,i)*Hgc;
   Hwc(:,:,i) = Hwb * Hbg(:,:,i) * Hgc; % 
   Hcw(:,:,i) = Hcg*inv(Hbg(:,:,i))*Hbw; % Hcw = Hcg*Hgb*Hbw  
end;


%Tsi labels:
Hg = Hbg;
Hc = Hcw;
%Hgij = Hgigj;
%Hcij = Hcicj;
Hc

K = (M*M-M)/2;               % Number of unique camera position pairs
A = zeros(3*K,3);            % will store: skew(Pgij+Pcij)
B = zeros(3*K,1);            % will store: Pcij - Pgij
k = 0;
for i = 1:M,
   for j = i+1:M;
      % by Tsai's convention
		Hgij = inv(Hg(:,:,j))*Hg(:,:,i); Rgij = Hgij(1:3,1:3);
		Hcij = Hc(:,:,j)*inv(Hc(:,:,i)); Rcij = Hcij(1:3,1:3);
      
		Pcij = rot2quat(Hcij);
		Pgij = rot2quat(Hgij);
      
      % Display to verify that ..
      % .. the following holds:
      Rcg = gHc(1:3,1:3); Rgij = Hgij(1:3,1:3); Rcij = Hcij(1:3,1:3); 

      [Rgij Rcg*Rcij*Rcg'] % Rgij = Rcg*Rcij*Rcg'
      [Pgij Rcg*Pcij     ] % Pgij = Rcg*Pcij
      
      k = k+1;
      A((3*k-3)+(1:3), 1:3) = skew(Pgij+Pcij);
      B((3*k-3)+(1:3))      = Pcij - Pgij;
         
   end;
end;


% Testing accuracy of A and B
% A*Pcg_=B

Rcg = gHc(1:3,1:3); 
Pcg_correct = rot2quat(Rcg);
Pcg_prime   = Pcg_correct/sqrt(4 - Pcg_correct'*Pcg_correct);


